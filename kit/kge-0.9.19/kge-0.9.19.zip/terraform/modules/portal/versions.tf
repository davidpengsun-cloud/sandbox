terraform {
  required_version = "~> 1.16"
  required_providers {
    google = { source = "hashicorp/google", version = ">= 8.5.0, < 9.0.0" }
  }
}
